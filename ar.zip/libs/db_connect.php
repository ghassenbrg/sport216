<?php
$conn = new mysqli("localhost","root","","sport216");
if($conn->connect_error) {
	die("error while trying to establish a connection with the database...");
} else {
	$conn->set_charset("utf8");
}
  $mypath = "http://localhost/ar/";
?>
