<div class="column" id="column-right">
  <nav class="right-sidebar">
    <center>
        <div class="sidebar-menu">
          <div class="fixed-menu">
            <a href="<?php echo $mypath;?>"><img class="sidebar-logo" src="<?php echo $mypath;?>images/resources/sport216-logo.png" /></a>
            <ul>
              <a href="<?php echo $mypath;?>"><li class="home"><figure class="image is-48x48px"><img class="ico" src="<?php echo $mypath;?>images/resources/home-icon.png" /></figure>الرئيسيّة</li></a>
              <a href="<?php echo $mypath;?>cat/2"><li class="cat2"><figure class="image is-48x48px"><img class="ico" src="<?php echo $mypath;?>images/resources/football-icon.png" /></figure>كرة القدم الوطنيّة</li></a>
              <a href="<?php echo $mypath;?>cat/3"><li class="cat3"><figure class="image is-48x48px"><img class="ico" src="<?php echo $mypath;?>images/resources/cl-icon.png" /></figure>كرة القدم العالميّة</li></a>
              <a href="<?php echo $mypath;?>cat/4"><li class="cat4"><figure class="image is-48x48px"><img class="ico" src="<?php echo $mypath;?>images/resources/player-icon.png" /></figure>المحترفين بالخارج</li></a>
              <a href="<?php echo $mypath;?>cat/5"><li class="cat5"><figure class="image is-48x48px"><img class="ico" src="<?php echo $mypath;?>images/resources/news-icon.png" /></figure>أخبار متفرقة</li></a>
              <a href="<?php echo $mypath;?>live"><li class="live"><figure class="image is-48x48px"><img class="ico" src="<?php echo $mypath;?>images/resources/tv-icon.png" /></figure>البث المباشر للمباريات</li></a>
            </ul>
        </div>
      </div>
    </center>
  </nav>
</div>
