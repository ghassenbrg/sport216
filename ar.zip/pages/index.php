<?php
	header("location: /?e=404");
	exit();
?>
