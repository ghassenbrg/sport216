<?php
	header("location: /ar/?e=404");
	exit();
?>
